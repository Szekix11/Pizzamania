/*A kód definiál egy showNavbar nevű függvényt, amelynek négy paramétere van: 
toggleId, navId, bodyId, és headerId. Ezek az azonosítók (ID-k), amelyek az HTML 
elemeket azonosítják.

Az if utasítás ellenőrzi, hogy a négy megadott azonosítóval rendelkező HTML 
elemek léteznek-e az oldalon. Azaz, a kód ellenőrzi, hogy minden szükséges elem megtalálható-e az oldalon, mielőtt megpróbálna rájuk 
eseménykezelőt telepíteni.

Ha az összes szükséges HTML elem megtalálható, akkor a függvény hozzárendel egy eseményfigyelőt (event listener) a toggle elemhez, általában 
egy gombhoz vagy ikonhoz, amelyre kattintva a navigációs menüt megjeleníthetjük vagy elrejthetjük.

Amikor a toggle elemre kattintanak, a függvény műveleteket hajt végre:

A nav elemnek hozzáadja vagy eltávolítja az "showa" osztályt, amely a navigációs menü megjelenítéséért felelős.
A toggle elemnek módosítja az ikont a "bx-x" osztályra vagy vissza, hogy vizuálisan jelezze a menü megnyitását vagy bezárását.
A bodypd és headerpd elemeknek hozzáad vagy eltávolít egy "body-pd" osztályt, amely esetleges testreszabott stílusokat vagy formázást alkalmaz 
az oldalon a navigációs menü megjelenítésekor vagy elrejtésekor.*/ 
const showNavbar = (toggleId, navId, bodyId, headerId) =>{
    const toggle = document.getElementById(toggleId),
    nav = document.getElementById(navId),
    bodypd = document.getElementById(bodyId),
    headerpd = document.getElementById(headerId)

    
    if(toggle && nav && bodypd && headerpd){
        toggle.addEventListener('click', ()=>{
           
            nav.classList.toggle('showa')
        
            toggle.classList.toggle('bx-x')
           
            bodypd.classList.toggle('body-pd')
           
            headerpd.classList.toggle('body-pd')
        })
    }
}

showNavbar('header-toggle','nav-bar','body-pd','header')
