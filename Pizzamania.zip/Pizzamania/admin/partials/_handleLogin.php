<?php
// Ellenőrzi, hogy a kérés POST kérés-e
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include '_dbconnect.php';
    // Felhasználó által megadott felhasználónév és jelszó
    $username = $_POST["username"];
    $password = $_POST["password"]; 
    // SQL lekérdezés a felhasználó adatainak ellenőrzésére a felhasználónév alapján
    $sql = "Select * from users where username='$username'"; 
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);
    // Ellenőrzi, hogy talált-e egyező felhasználót
    if ($num == 1){
        $row=mysqli_fetch_assoc($result);
        $userType = $row['userType'];
        // Ellenőrzi a felhasználó típusát (admin vagy nem admin)
        if($userType == 1) {
            $userId = $row['id'];
             // Ellenőrzi a jelszó helyességét
            if (password_verify($password, $row['password'])){ 
                // Sikeres bejelentkezés esetén munkamenet elindítása és adatok tárolása
                session_start();
                $_SESSION['adminloggedin'] = true;
                $_SESSION['adminusername'] = $username;
                $_SESSION['adminuserId'] = $userId;
                // Átirányítás a sikeres bejelentkezés oldalra
                header("location: /Pizzamania/admin/index.php?loginsuccess=true");
                exit();
            } 
            else{
                // Hibás jelszó esetén átirányítás a bejelentkezés oldalra hibaüzenettel
                header("location: /Pizzamania/admin/login.php?loginsuccess=false");
            }
        }
        else {
            // Nem admin felhasználó esetén átirányítás a bejelentkezés oldalra hibaüzenette
            header("location: /Pizzamania/admin/login.php?loginsuccess=false");
        }
    } 
    else{
        // Nincs egyező felhasználó esetén átirányítás a bejelentkezés oldalra hibaüzenettel
        header("location: /Pizzamania/admin/login.php?loginsuccess=false");
    }
}    
?>