<?php

session_start();
echo "Kijelentkezni. Kérlek várj..";
unset($_SESSION["loggedin"]);
unset($_SESSION["username"]);
unset($_SESSION["userId"]);

// session_unset();
// session_destroy();

header("location: /Pizzamania/index.php");
?>