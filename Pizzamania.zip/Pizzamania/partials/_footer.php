<div class="footer container-fluid bg-dark text-light" style="position: fixed; bottom: 0; width: 100%;">
    <p class="text-center py-2 mb-0">SZTE JGYPK rendszerfejlesztés 2023 <a href="https://hu.wikipedia.org/wiki/Pizza" target="_blank" rel="noopener noreferrer">Pizza története</a></p>
</div>
